package com.snake;

public class Main
{
    static Game game;

    public static void main(String[] args)
    {
        game = new Game();
        game.run();
    }
}
